#!/bin/sh
# This is the generic flash script doip_uds_flash_server will run
# It will flash the images of the inactive boot chain partitions
# We cannot make it more generic because the flash client only sends
# a single flash file
set -e

printf "start flash\n" >> /data/doip_uds_flash/flash_log.txt

KEY=$(cat /data/doip_uds_flash/image_key)
if [ -z "${KEY}" ]; then
  printf "ERROR: image key is empty" >> $LOG_FILE
  exit 1
fi

BASE="/data/doip_uds_flash/"
LOG_FILE="${BASE}/flash_log.txt"
IMAGE_FILE_DIR="/data/doip_uds_flash/images-du-package/tii-a"
mv "${IMAGE_FILE_DIR}/flash-images.tar.xz" "${BASE}/enc-flash-images.tar.xz"
# using nil IV is not ideal but it's hard to change on FAW side
# we include a random file in the tar package to compensate
openssl enc -d -aes-256-cbc -K "${KEY}" -iv 0 \
-in "${BASE}/enc-flash-images.tar.xz" \
-out "${BASE}/flash-images.tar.xz" 2>&1
printf "decoded image file\n" >> $LOG_FILE

printf "unzipping image file\n" >> $LOG_FILE
tar -zxf "${BASE}/flash-images.tar.xz"  -C "${BASE}"
printf "unzipped image file\n" >> $LOG_FILE

sh "${BASE}/flash_impl.sh"

