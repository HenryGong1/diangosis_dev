#!/bin/sh

# we don't need these nodes during flashing
# and the ADU is going to restart after the flashing
if [ -e /opt/plusai/launch/j7-l4e/stop-all.sh ]; then
    /opt/plusai/launch/j7-l4e/stop-all.sh
fi
hamlaunch stop
/usr/local/driveupdate/start_du_service.sh 2>&1 >> /data/doip_uds_flash/flash_log.txt
sleep 60