#!/bin/sh
#!/bin/sh
# This is the generic flash reboot script doip_uds_flash_server will run
sh "/data/doip_uds_flash/flash_check_impl.sh"