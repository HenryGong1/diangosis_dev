#!/bin/sh

#install nvidia drive update package
mkdir -p /data/doip_uds_flash/images-du-package/tii-a
mkdir -p /mnt
set -e
ln -sf /data/doip_uds_flash/images-du-package /mnt/images-du-package

date >> /data/doip_uds_flash/flash_log.txt
echo "server started\n" >> /data/doip_uds_flash/flash_log.txt
