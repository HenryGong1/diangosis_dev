#!/bin/sh
# This is the generic bootchain switching script doip_uds_flash_server will run
# It will switch to the inactive bootchain
sh "/data/doip_uds_flash/flash_confirm_impl.sh"