#!/bin/sh
printf "start flash\n" >> /data/doip_uds_flash/flash_log.txt
# abort any pending updates
/samples/driveupdate/sample_driveupdate -a
printf "aborted previous updates\n" >> /data/doip_uds_flash/flash_log.txt
set -e

KEY=""
if [ -f /data/doip_uds_flash/image_key ]; then
    KEY=`cat /data/doip_uds_flash/image_key`
else
    KEY=`cat /opt/plusai/share/doip_uds_flash/image_key`
fi

IMAGE_FILE_DIR=/data/doip_uds_flash/images-du-package/tii-a

if [ ! -z "${KEY}" ]; then
    printf "image file is encyrpted\n" >> /data/doip_uds_flash/flash_log.txt
    mv "${IMAGE_FILE_DIR}/flash-images.tar.xz" \
    "${IMAGE_FILE_DIR}/enc-flash-images.tar.xz"
    openssl enc -d -aes-256-ecb -K "${KEY}" \
    -in "${IMAGE_FILE_DIR}/enc-flash-images.tar.xz" \
    -out "${IMAGE_FILE_DIR}/flash-images.tar.xz" 2>&1
    printf "decoded image file\n" >> /data/doip_uds_flash/flash_log.txt
fi

printf "unzipping image file\n" >> /data/doip_uds_flash/flash_log.txt
tar -zxf "${IMAGE_FILE_DIR}/flash-images.tar.xz" \
 -C /data/doip_uds_flash/images-du-package
printf "unziped image file\n" >> /data/doip_uds_flash/flash_log.txt

chown -R 3360:3360 /data/doip_uds_flash
sleep 5
(echo "y"
sleep 2
echo "y") | /samples/driveupdate/sample_driveupdate -d /data/doip_uds_flash/images-du-package/1_deploy_image.json
printf "1. sample_driveupdate 1_dploy_image.json \n" >> /data/doip_uds_flash/flash_log.txt