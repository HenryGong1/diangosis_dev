#!/bin/sh
echo 1 > /data/doip_uds_flash/flash_state.txt
echo "2. driveupdate 2_reboot.json (1)" >> /data/doip_uds_flash/flash_log.txt
sync
sleep 10
(echo "y") | /samples/driveupdate/sample_driveupdate -d /data/doip_uds_flash/images-du-package/2_reboot.json 2>&1
echo "2. driveupdate 2_reboot.json (2)" >> /data/doip_uds_flash/flash_log.txt
sync
sleep 10
(echo "y") | /samples/driveupdate/sample_driveupdate -d /data/doip_uds_flash/images-du-package/2_reboot.json 2>&1
echo "2. driveupdate 2_reboot.json (3)" >> /data/doip_uds_flash/flash_log.txt
sync
sleep 10
(echo "y") | /samples/driveupdate/sample_driveupdate -d /data/doip_uds_flash/images-du-package/2_reboot.json 2>&1
# should not reach here if the previous step succeeeds
echo "E. driveupdate 2_reboot.json failed" >> /data/doip_uds_flash/flash_log.txt
sync
sleep 10