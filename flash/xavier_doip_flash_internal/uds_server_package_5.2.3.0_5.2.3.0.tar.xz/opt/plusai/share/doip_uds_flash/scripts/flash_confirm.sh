#!/bin/sh
# exit 1 if needs reboot, 0 otherwise

if [ ! -e /data/doip_uds_flash/flash_state.txt ]; then
    exit 0
fi

value=`cat /data/doip_uds_flash/flash_state.txt`

if [ $value -eq 1 ]; then
    echo "performing second phase of doip uds flashing" >> /data/doip_uds_flash/flash_log.txt
    echo 0 > /data/doip_uds_flash/flash_state.txt
    sleep 20
    /usr/local/driveupdate/start_du_service.sh 2>&1
    echo "start_du_service" >> /data/doip_uds_flash/flash_log.txt
    ifconfig vlan200 down 2>&1
    sleep 20
    echo "disable vlan200 to prevent dcdc reset" >> /data/doip_uds_flash/flash_log.txt
    (echo "y") | /samples/driveupdate/sample_driveupdate -d /data/doip_uds_flash/images-du-package/2_reboot.json 2>&1
    echo "3. driveupdate 2_reboot.json" >> /data/doip_uds_flash/flash_log.txt
    /samples/driveupdate/sample_driveupdate -a 2>&1
    sync
    sleep 20
    /opt/plusai/lib/doip_uds_flash/doip_uds_flash_reboot 2>&1
    exit 1
fi
exit 0