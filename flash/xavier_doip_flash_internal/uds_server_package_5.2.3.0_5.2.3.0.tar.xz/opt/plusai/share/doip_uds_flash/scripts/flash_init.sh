#!/bin/sh

#install nvidia drive update package
rm -rf /data/doip_uds_flash/images-du-package
mkdir -p /data/doip_uds_flash
mkdir -p /mnt
set -e
cp -rf /opt/plusai/share/doip_uds_flash/images-du-package /data/doip_uds_flash
ln -sf /data/doip_uds_flash/images-du-package /mnt/images-du-package

date >> /data/doip_uds_flash/flash_log.txt
echo "server started\n" >> /data/doip_uds_flash/flash_log.txt

